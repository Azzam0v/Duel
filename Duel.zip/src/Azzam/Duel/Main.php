<?php

namespace Azzam\Duel;

use Azzam\Listeners\PlayerDropItemListener;
use cooldogedev\BedrockEconomy\api\BedrockEconomyAPI;
use cooldogedev\BedrockEconomy\api\legacy\ClosureContext;
use jojoe77777\FormAPI\CustomForm;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\VanillaItems;
use pocketmine\lang\Language;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\world\Position;

class Main extends PluginBase implements Listener
{
    public $request = [];
    public $rplayer2 = [];
    public $money = [];
    public $kit = [];
    public $money2;

    protected function onEnable(): void
    {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getServer()->getWorldManager()->loadWorld("Duel");
    }

    public function onCommand(CommandSender $player, Command $command, string $label, array $args): bool
    {
        if ($player instanceof Player){
            if ($command->getName() === "duel"){
                if (isset($args[0]) && ($args[0] === "accept" or $args[0] === "deny" or $args[0] === 'cancel' or $args[0] === 'tp')){
                    if ($args[0] === 'accept'){
                        if (isset($this->rplayer2[$player->getName()])){
                            $contents = $player->getInventory()->getContents();
                            $armor_inv = $player->getArmorInventory();
                            $armor = $armor_inv->getContents();
                            $helmet = $armor_inv->getHelmet()->getTypeId();
                            $chessplate = $armor_inv->getChestplate()->getTypeId();
                            $pantalon = $armor_inv->getLeggings()->getTypeId();
                            $bottes = $armor_inv->getBoots()->getTypeId();

                            if ($helmet == 0 && $chessplate == 0 && $pantalon == 0 && $bottes == 0){
                                if(empty($contents) && empty($armor)){
                                    $joueur = $this->rplayer2[$player->getName()];
                                    $joueur2 = $this->getServer()->getPlayerExact($joueur);
                                    $money = $this->money[$joueur];
                                    $contents2 = $joueur2->getInventory()->getContents();
                                    $armor2_inv = $joueur2->getArmorInventory();
                                    $armor2 = $armor2_inv->getContents();
                                    $helmet2 = $armor2_inv->getHelmet()->getTypeId();
                                    $chessplate2 = $armor2_inv->getChestplate()->getTypeId();
                                    $pantalon2 = $armor2_inv->getLeggings()->getTypeId();
                                    $bottes2 = $armor2_inv->getBoots()->getTypeId();

                                    if ($helmet2 == 0 && $chessplate2 == 0 && $pantalon2 == 0 && $bottes2 == 0){
                                        if(empty($contents2) && empty($armor2)){
                                            $world = $this->getServer()->getWorldManager()->getWorldByName("Duel");
                                            $players = $world->getPlayers();
                                            if ($this->hasEnoughMoney($joueur, $this->money[$player->getName()]))
                                            {
                                                if ($this->hasEnoughMoney($joueur2, $this->money[$player->getName()]))
                                                {
                                                    if(count($players) > 1){
                                                        $player->sendMessage('§9>> §fUn duel est déjà en cours, veuillez patienter.');
                                                    } else {
                                                        if($player->getGamemode() === GameMode::SURVIVAL()){
                                                            $player->setAllowFlight(false);
                                                            $player->setFlying(false);
                                                        }if($joueur2->getGamemode() === GameMode::SURVIVAL()){
                                                            $joueur2->setAllowFlight(false);
                                                            $joueur2->setFlying(false);
                                                        }
                                                        $player->getEffects()->clear();
                                                        $joueur2->getEffects()->clear();
                                                        $player->sendMessage("§9>> §fVous avez accepté le duel du Joueur§9 ".$joueur2->getName()." §fpour la somme de§9 $money$");
                                                        $joueur2->sendMessage("§9>> §fLe joueur §9".$player->getName()." §fà accepté votre duel pour la somme de§9 $money$");
                                                        $this->getServer()->broadcastMessage("§9[§e!!§9] §fUn Duel a été lancé, l'arène est donc pleine !");
                                                        $this->getScheduler()->scheduleRepeatingTask(new DuelTask($this, $player), 20);
                                                        $this->getScheduler()->scheduleRepeatingTask(new DuelTask($this, $joueur2), 20);
                                                        $this->getScheduler()->scheduleRepeatingTask(new DuelTimer($this), 20);
                                                        $player->setHealth(20);
                                                        $joueur2->setHealth(20);
                                                        $rdm = mt_rand(1,5);
                                                        if ($rdm === 1){
                                                            $player->teleport(new Position(-48,39,-32,$player->getServer()->getWorldManager()->getWorldByName("Duel")));
                                                            $joueur2->teleport(new Position(-48,39,8,$player->getServer()->getWorldManager()->getWorldByName("Duel")));
                                                        }if ($rdm === 2){
                                                            $player->teleport(new Position(-290,39,-32,$player->getServer()->getWorldManager()->getWorldByName("Duel")));
                                                            $joueur2->teleport(new Position(-290,39,8,$player->getServer()->getWorldManager()->getWorldByName("Duel")));
                                                        }if ($rdm === 3){
                                                            $player->teleport(new Position(-538,39,-32,$player->getServer()->getWorldManager()->getWorldByName("Duel")));
                                                            $joueur2->teleport(new Position(-538,39,8,$player->getServer()->getWorldManager()->getWorldByName("Duel")));
                                                        }if ($rdm === 4){
                                                            $player->teleport(new Position(-166,80,-188,$player->getServer()->getWorldManager()->getWorldByName("Duel")));
                                                            $joueur2->teleport(new Position(-166,80,-228,$player->getServer()->getWorldManager()->getWorldByName("Duel")));
                                                        }if ($rdm === 5){
                                                            $player->teleport(new Position(-407,113,203,$player->getServer()->getWorldManager()->getWorldByName("Duel")));
                                                            $joueur2->teleport(new Position(-407,113,243,$player->getServer()->getWorldManager()->getWorldByName("Duel")));
                                                        }
                                                        unset($this->rplayer2[$player->getName()]);
                                                        unset($this->request[$joueur2->getName()]);
                                                        $this->money2 = $this->money[$player->getName()];
                                                    }
                                                }else{
                                                    $joueur2->sendMessage("§9>>§f Vous n'avez pas assez d'argent pour lancer votre duel !");
                                                }

                                            }else{
                                                $player->sendMessage("§9>>§f Vous n'avez pas assez d'argent pour lancer votre duel !");
                                            }
                                        }else{
                                            $player->sendMessage("§9>> §fLe Joueur §9".$joueur2->getName()." §fdoit vider son inventaire avant de pouvoir accepter le duel !");
                                            $joueur2->sendMessage("§9>> §fVous devez §9vider §fvotre inventaire avant de pouvoir lancer le duel !");
                                        }
                                    }else{
                                        $player->sendMessage("§9>> §fLe Joueur §9".$joueur2->getName()." §fdoit vider son inventaire avant de pouvoir accepter le duel !");
                                        $joueur2->sendMessage("§9>> §fVous devez §9vider §fvotre inventaire avant de pouvoir lancer le duel !");
                                    }
                                }else{
                                    $player->sendMessage("§9>> §fVous devez §9vider §fvotre inventaire avant de pouvoir lancer le duel !");
                                }
                            }else{
                                $player->sendMessage("§9>> §fVous devez §9vider §fvotre inventaire avant de pouvoir lancer le duel !");
                            }
                        }else{
                            $player->sendMessage("§9>> §fVous n'avez aucune demande de duel !");
                        }
                    }if ($args[0] === 'deny'){
                        if (isset($this->rplayer2[$player->getName()])){
                            $joueur = $this->rplayer2[$player->getName()];
                            $joueur2 = $this->getServer()->getPlayerByPrefix($joueur);
                            $money = $this->money[$joueur];
                            $player->sendMessage("§9>> §fVous avez refuser le duel du joueur§9 ".$joueur." §fpour la somme de§9 $money$");
                            $joueur2->sendMessage("§9>> §fLe joueur §9".$player->getName()." §fà refuser votre duel pour la somme de§9 $money$");

                            unset($this->rplayer2[$player->getName()]);
                            unset($this->request[$joueur]);
                            unset($this->money[$player->getName()]);
                            unset($this->money[$joueur]);
                            unset($this->kit[$player->getName()]);
                            unset($this->kit[$joueur]);
                        }else{
                            $player->sendMessage("§9>> §fVous n'avez aucune demande de duel !");
                        }
                    }if ($args[0] === 'tp'){
                        if ($player->getGamemode() === GameMode::CREATIVE()){
                            $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName("Duel")->getSafeSpawn());
                            $player->sendMessage("§9>> §fVous avez été teleporté au monde §9Duel !");
                        }else{
                            $player->sendMessage("§9>> §fVous devez être en §9Créatif §fpour executer cette commande !");
                        }
                    }
                }else{
                    $this->MainForm($player);
                }
            }
        }
        return true;
    }

    public function hasEnoughMoney($player, $money): bool{
        BedrockEconomyAPI::legacy()->getPlayerBalance($player->getName(), ClosureContext::create(
            function (?int $balance) use ($money, $player) {
                if ($balance >= $money)
                {
                    return true;
                }else{
                    $player->sendMessage("§9>>§f Vous n'avez pas assez d'argent !");
                    return false;
                }
            },
        ));
        return true;
    }

    public function MainForm(Player $player)
    {
        $form = new CustomForm(function (Player $player, array $data = null) {
            $re = $data;
            if ($re === null)
            {
                return true;
            }
            if ($data[1] !== ""){
                $joueur2 = $this->getServer()->getPlayerExact($data[1]);
                if ($joueur2 !== null && $joueur2->getName() !== $player->getName()){
                    if (is_numeric($data[2])){
                        if ($data[2] > 999){
                            $money = $data[2];
                            BedrockEconomyAPI::legacy()->getPlayerBalance($player->getName(), ClosureContext::create(
                                function (?int $balance) use ($money, $player, $data, $joueur2): void {
                                    if ($balance >= $money)
                                    {
                                        if ($data[3] === "Gapple" || $data[3] === "Potion" || $data[3] === "Cheat"){
                                            if (!isset($this->request[$player->getName()])){
                                                if (!isset($this->request[$joueur2->getName()])){
                                                    if (!isset($this->rplayer2[$player->getName()])){
                                                        if (!isset($this->rplayer2[$joueur2->getName()])){
                                                            $player->sendMessage("§9>> §fVotre demande de duel en §9".$data[3]." §fà été envoyée au joueur §9".$joueur2->getName().", §fle gagnant remportera§9 $data[2]$ §f! Faites §9/duel cancel §fpour annuler le duel !");
                                                            $joueur2->sendMessage("§9>> §fLe joueur§9 ".$player->getName()." §fvous a demandé en duel en §9".$data[3]." §f! le gagnant remportera§9 $data[2]$ §f! Faites §9/duel accept §fou §9/duel deny §f!");
                                                            $this->request[$player->getName()] = $joueur2->getName();
                                                            $this->rplayer2[$joueur2->getName()] = $player->getName();
                                                            $this->money[$player->getName()] = $data[2];
                                                            $this->money[$joueur2->getName()] = $data[2];
                                                            $this->kit[$player->getName()] = $data[3];
                                                            $this->kit[$joueur2->getName()] = $data[3];
                                                        }else{
                                                            $player->sendMessage("§9>> §fLe Joueur ".$joueur2->getName()." à déjà été demandé en Duel !");
                                                        }
                                                    }else{
                                                        $player->sendMessage("§9>> §fVous avez déjà demandé quelqu'un en duel, veuillez attendre !");
                                                    }

                                                }else{
                                                    $player->sendMessage("§9>> §fLe Joueur ".$joueur2->getName()." à déjà été demandé en Duel !");
                                                }
                                            }else{
                                                $player->sendMessage("§9>> §fVous avez déjà demandé quelqu'un en duel, veuillez attendre !");
                                            }
                                        }else{
                                            $player->sendMessage("§9>>§f Veuillez entrer un nom de kit valide ! §9[Gapple, Potion, Cheat]");
                                        }
                                    }else{
                                        $player->sendMessage("§9>>§f Vous n'avez pas assez d'argent pour lancer votre duel !");
                                    }
                                },
                            ));
                        }else{
                            $player->sendMessage("§9>> §fLa mise minimale est de §91000$ §f!");
                        }

                    }else{
                        $player->sendMessage("§9>> §fVeuillez entrer une somme valide !");

                    }
                }else{
                    $player->sendMessage("§9>> §fLe Joueur n'est pas en ligne !");
                }
            }else{
                $player->sendMessage("§9>> §fVeuillez entrer un pseudo valide !");
            }
        });
        $form->setTitle("Duel");
        $form->addLabel("§fDemander un joueur en Duel");
        $form->addInput("§fEntrez §9le pseudo §fdu joueur.", "Pseudo");
        $form->addInput("§fEntrez §9la somme §fque vous voulez miser.", "5000");
        $form->addInput("§fChoix du Kit", "Gapple, Potion ou Cheat");

        $form->sendToPlayer($player);
        return $form;
    }

    public function onDamage(EntityDamageByEntityEvent $event){
        $player = $event->getDamager();
        $entity = $event->getEntity();
        if ($player instanceof Player) {
            if ($event->getFinalDamage() >= $entity->getHealth() && $entity->getWorld()->getFolderName() === "Duel") {
                if ($entity instanceof Player){
                    $entity->getEffects()->clear();
                    $entity->getInventory()->clearAll();
                    $entity->sendMessage("§9>> §fVous avez §9perdu §fvotre Duel, vous avez été retiré de §9".$this->money[$entity->getName()]."$");
                    $entity->teleport(Server::getInstance()->getWorldManager()->getWorldByName("AzzamSpawn")->getSafeSpawn());
                    BedrockEconomyAPI::legacy()->subtractFromPlayerBalance($entity, $this->money[$entity->getName()]);

                    $this->clearArmor($entity);
                    $entity->sendTitle("§9Duel", "§fVous avez perdu le Duel !");
                    $this->getServer()->broadcastMessage("§9[§e!!§9] §fUn Duel s'est terminé, l'arène est donc libre !");
                    $entity->setHealth(20);
                    $entity->getInventory()->clearAll();

                    $player->getEffects()->clear();
                    $player->sendTitle("§9Duel", "§fVous avez remporté le Duel !");
                    $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName("AzzamSpawn")->getSafeSpawn());
                    $player->getInventory()->clearAll();
                    $this->clearArmor($player);
                    $player->setHealth(20);
                    BedrockEconomyAPI::legacy()->subtractFromPlayerBalance($entity, $this->money[$entity->getName()]);
                    $player->sendMessage("§9>> §fVous avez §9remporter§f votre Duel, vous avez été rémunéré d'une somme de §9".$this->money[$entity->getName()]."$");
                    unset($this->money[$player->getName()]);
                    unset($this->money[$entity->getName()]);
                    unset($this->rplayer2[$player->getName()]);
                    unset($this->request[$entity->getName()]);
                    unset($this->kit[$player->getName()]);
                    unset($this->kit[$entity->getName()]);
                    $this->getScheduler()->cancelAllTasks();
                }
            }
        }

    }

    public function onJoin(PlayerJoinEvent $event)
    {
        $player = $event->getPlayer();
        if ($player->getWorld()->getFolderName() === "Duel"){
            $player->getInventory()->clearAll();
            $player->getEffects()->clear();
            $this->clearArmor($player);
        }
    }

    public function clearArmor(Player $player){
        $player->getArmorInventory()->setHelmet(VanillaItems::AIR());
        $player->getArmorInventory()->setChestplate(VanillaItems::AIR());
        $player->getArmorInventory()->setLeggings(VanillaItems::AIR());
        $player->getArmorInventory()->setBoots(VanillaItems::AIR());
    }

    public function onPlayerDeath(PlayerDeathEvent $event) {
        $player = $event->getPlayer();
        $drops = $event->getDrops();

        if ($player->getWorld()->getDisplayName() === "Duel"){
            foreach($drops as $drop) {
                $event->setDrops([]);
            }
            if (isset($this->request[$player->getName()])){
                if (isset($this->rplayer2[$this->request[$player->getName()]])){
                    unset($this->rplayer2[$this->request[$player->getName()]]);
                }
                unset($this->request[$player->getName()]);
            }if (isset($this->rplayer2[$player->getName()])){
                if (isset($this->request[$this->rplayer2[$player->getName()]])){
                    unset($this->request[$this->rplayer2[$player->getName()]]);
                }
                unset($this->rplayer2[$player->getName()]);
            }
        }
    }

    public function onQuit(PlayerQuitEvent $event){
        $player = $event->getPlayer();
        if ($player->getWorld()->getDisplayName() === "Duel"){
            if ($player->getGamemode() === GameMode::SURVIVAL()){
                $this->getScheduler()->cancelAllTasks();
                $player->getInventory()->clearAll();
                $this->clearArmor($player);
                $player->getEffects()->clear();

                if (isset($this->money2)){
                    $money = $this->money2;
                    $world = $this->getServer()->getWorldManager()->getWorldByName("Duel");
                    $this->onWinDuel($world, $player, $money);
                }else{
                    $world = $this->getServer()->getWorldManager()->getWorldByName("Duel");
                    $this->onWinDuel($world, $player, 1000);
                }

                if (isset($this->request[$player->getName()])){
                    if (isset($this->rplayer2[$this->request[$player->getName()]])){
                        unset($this->rplayer2[$this->request[$player->getName()]]);
                    }
                    unset($this->request[$player->getName()]);
                }if (isset($this->rplayer2[$player->getName()])){
                    if (isset($this->request[$this->rplayer2[$player->getName()]])){
                        unset($this->request[$this->rplayer2[$player->getName()]]);
                    }
                    unset($this->rplayer2[$player->getName()]);
                }
            }

        }

    }

    public function onWinDuel($world, $player){
        foreach ($world->getPlayers() as $players){
            if ($players->getGamemode() === GameMode::SURVIVAL() && $players->getName() !== $player->getName()){
                $players->getEffects()->clear();
                $this->getScheduler()->cancelAllTasks();

                $players->teleport(Server::getInstance()->getWorldManager()->getWorldByName("AzzamSpawn")->getSafeSpawn());
                $players->getInventory()->clearAll();
                $this->clearArmor($players);
                $players->setImmobile(false);
                unset($this->money2);

            }
        }
    }

    public function onDrop(PlayerDropItemEvent $event){
        $item = $event->getItem();
        $player = $event->getPlayer();
        if ($player->getWorld()->getFolderName() === "Duel"){
            $event->cancel();
        }
    }


}