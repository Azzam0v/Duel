<?php

namespace Azzam\Duel;

use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\world\sound\ClickSound;
use SxxCodezx\Sounds;

class DuelTask extends Task
{
    private $plugin;
    private $player;
    public $time = [];

    public function __construct(Main $plugin, Player $player)
    {
        $this->plugin = $plugin;
        $this->player = $player;
        $this->time[$this->player->getName()] = 10;
        $this->player->setNoClientPredictions(true);
        $this->player->getInventory()->clearAll();
    }

    public function onRun(): void
    {
        if ($this->player->isOnline()) {
            $this->timer();
                if ($this->time[$this->player->getName()] <= 6) {
                    if ($this->player->isOnline()) {
                        if ($this->time[$this->player->getName()] === 6){
                            Sounds::addSound($this->player, 'note.bass', 50, 1);
                            $this->player->sendTitle("§45");
                        }if ($this->time[$this->player->getName()] === 5){
                            Sounds::addSound($this->player, 'note.bass', 50, 1);
                            $this->player->sendTitle("§c4");
                        }
                        if ($this->time[$this->player->getName()] === 4){
                            Sounds::addSound($this->player, 'note.bass', 50, 1);
                            $this->player->sendTitle("§63");
                        }if ($this->time[$this->player->getName()] === 3){
                            Sounds::addSound($this->player, 'note.bass', 50, 1);
                            $this->player->sendTitle("§e2");
                        }if ($this->time[$this->player->getName()] === 2){
                            Sounds::addSound($this->player, 'note.bass', 50, 1);
                            $this->player->sendTitle("§a1");
                            $this->onInventory($this->player);
                        }if ($this->time[$this->player->getName()] == 1){
                            $this->player->setNoClientPredictions(false);
                            $this->player->sendTitle("§9Duel", "§fDébut du Duel !");
                        }
                    }else{
                        $this->plugin->getScheduler()->cancelAllTasks();
                    }

                }

        }else{
            $this->plugin->getScheduler()->cancelAllTasks();
        }
    }

    public function timer(){
        if (!$this->time[$this->player->getName()] == 0) {
            $this->time[$this->player->getName()]--;
        }
    }

    public function onInventory(Player $player){
        $player->getEffects()->clear();
        if ($this->plugin->kit[$player->getName()] === "Gapple"){
            $sword = VanillaItems::DIAMOND_SWORD();
            $sword->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 4));
            $player->getInventory()->addItem($sword);

            $player->getInventory()->addItem(VanillaItems::GOLDEN_APPLE()->setCount(5));
            $player->getInventory()->addItem(ItemFactory::getInstance()->get(400,0,1));

            $helmet = VanillaItems::DIAMOND_HELMET();
            $helmet->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
            $player->getArmorInventory()->setHelmet($helmet);

            $chestplate = VanillaItems::DIAMOND_CHESTPLATE();
            $chestplate->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
            $player->getArmorInventory()->setChestplate($chestplate);

            $leggings = VanillaItems::DIAMOND_LEGGINGS();
            $leggings->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
            $player->getArmorInventory()->setLeggings($leggings);

            $boots = VanillaItems::DIAMOND_BOOTS();
            $boots->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
            $player->getArmorInventory()->setBoots($boots);
        }if ($this->plugin->kit[$player->getName()] === "Potion"){
            $sword = VanillaItems::DIAMOND_SWORD();
            $sword->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 5));
            $player->getInventory()->addItem($sword);

            $player->getInventory()->addItem(ItemFactory::getInstance()->get(368,0,8));
            $player->getInventory()->addItem(ItemFactory::getInstance()->get(373,14,1));
            $player->getInventory()->addItem(ItemFactory::getInstance()->get(438,22,33));

            $helmet = VanillaItems::DIAMOND_HELMET();
            $helmet->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
            $player->getArmorInventory()->setHelmet($helmet);

            $chestplate = VanillaItems::DIAMOND_CHESTPLATE();
            $chestplate->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
            $player->getArmorInventory()->setChestplate($chestplate);

            $leggings = VanillaItems::DIAMOND_LEGGINGS();
            $leggings->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
            $player->getArmorInventory()->setLeggings($leggings);

            $boots = VanillaItems::DIAMOND_BOOTS();
            $boots->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
            $player->getArmorInventory()->setBoots($boots);
        }if ($this->plugin->kit[$player->getName()] === "Cheat"){
            $sword = VanillaItems::DIAMOND_SWORD();
            $sword->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 5));
            $player->getInventory()->addItem($sword);

            $player->getInventory()->addItem(VanillaItems::ENCHANTED_GOLDEN_APPLE()->setCount(2));

            $helmet = VanillaItems::DIAMOND_HELMET();
            $helmet->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
            $player->getArmorInventory()->setHelmet($helmet);

            $chestplate = VanillaItems::DIAMOND_CHESTPLATE();
            $chestplate->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
            $player->getArmorInventory()->setChestplate($chestplate);

            $leggings = VanillaItems::DIAMOND_LEGGINGS();
            $leggings->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
            $player->getArmorInventory()->setLeggings($leggings);

            $boots = VanillaItems::DIAMOND_BOOTS();
            $boots->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
            $player->getArmorInventory()->setBoots($boots);
        }
    }

}