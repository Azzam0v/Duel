<?php

namespace Azzam\Duel;

use pocketmine\item\ItemFactory;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use SxxCodezx\Sounds;

class DuelTimer extends Task
{
    private $plugin;
    public $time;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
        $this->time = 190;
    }

    public function onRun(): void
    {
        $this->timer();
        $world = Server::getInstance()->getWorldManager()->getWorldByName("Duel");
        foreach ($world->getPlayers() as $players){
            if ($this->time === 180){
                Sounds::addSound($players, 'note.bass', 50, 1);
                $players->sendMessage("§9>> §fPlus que §9".$this->time." secondes §favant la fin du duel !");
            }if ($this->time === 120){
                Sounds::addSound($players, 'note.bass', 50, 1);
                $players->sendMessage("§9>> §fPlus que §9".$this->time." secondes §favant la fin du duel !");
            }
            if ($this->time === 60){
                Sounds::addSound($players, 'note.bass', 50, 1);
                $players->sendMessage("§9>> §fPlus que §9".$this->time." secondes §favant la fin du duel !");
            }if ($this->time === 30){
                Sounds::addSound($players, 'note.bass', 50, 1);
                $players->sendMessage("§9>> §fPlus que §9".$this->time." secondes §favant la fin du duel !");
                $players->sendTitle("§9".$this->time." secondes");
            }if ($this->time === 10){
                Sounds::addSound($players, 'note.bass', 50, 1);
                $players->sendMessage("§9>> §fPlus que §9".$this->time." secondes §favant la fin du duel !");
                $players->sendTitle("§9".$this->time." secondes");
            }if ($this->time === 3){
                Sounds::addSound($players, 'note.bass', 50, 1);
                $players->sendTitle("§9".$this->time." secondes");
            }if ($this->time === 2){
                Sounds::addSound($players, 'note.bass', 50, 1);
                $players->sendTitle("§9".$this->time." secondes");
            }if ($this->time == 1){
                Sounds::addSound($players, 'note.bass', 50, 1);
                $players->teleport(Server::getInstance()->getWorldManager()->getWorldByName("AzzamSpawn")->getSafeSpawn());
                $players->getInventory()->clearAll();
                $this->clearArmor($players);
                $players->sendTitle("§9Duel", "§fMatch nul !");
                $players->setImmobile(false);
                $players->getEffects()->clear();
                unset($this->money2);

            }
        }
    }

    public function timer(){
        if (!$this->time == 0) {
            $this->time--;
        }else{
            $this->plugin->getScheduler()->cancelAllTasks();
        }
    }

    public function clearArmor(Player $player){
        $player->getEffects()->clear();
        $player->getArmorInventory()->setHelmet(VanillaItems::AIR());
        $player->getArmorInventory()->setChestplate(VanillaItems::AIR());
        $player->getArmorInventory()->setLeggings(VanillaItems::AIR());
        $player->getArmorInventory()->setBoots(VanillaItems::AIR());
    }


}